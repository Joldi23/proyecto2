IF NEW.monto >= 100 THEN
    UPDATE usuarios
    SET membresia = TRUE
    WHERE dni = NEW.id_usuario;
END IF;
